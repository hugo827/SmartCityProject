import './App.css';



import Way from './routes/routes';


function App() {
    return (
        <div className="App">
          <header className="App-header">
              <Way></Way>
          </header>
        </div>
  );
}

export default App;

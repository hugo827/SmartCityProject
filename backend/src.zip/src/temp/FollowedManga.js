/*
import React from 'react';
import Table from "../component/Table";

export default function FollowedManga(props) {

    const colFollowedManga = ["id_followed_manga", "state", "fk_manga", "fk_user"];

    return (
        <Table name="Followed_manga" colonnes={colFollowedManga}></Table>
    )
}

*/
import React from 'react';


class Error extends React.Component {


    render() {
        return (
            <div className="home">
                <p>Vous avez essayé d'acceder a un élément qui n'existe pas !</p>
            </div>
        )
    }
}


export default Error;
